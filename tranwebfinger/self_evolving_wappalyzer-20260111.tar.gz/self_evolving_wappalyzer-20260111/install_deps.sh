#!/bin/bash

# 安装依赖

echo "开始安装依赖..."

# 检查Python版本
python3 --version

# 安装pip依赖
echo "安装Python依赖..."
pip3 install requests scikit-learn numpy flask

echo "依赖安装完成！"
