# 自进化Wappalyzer规则系统技术文档

## 1. 系统概述

自进化Wappalyzer规则系统是一个智能的网站技术检测平台，能够自动获取真实网站数据，通过机器学习不断优化检测规则，实现自我进化。

### 1.1 核心功能

- **智能网站目标获取**：从多种来源获取真实网站，支持行业筛选
- **多维度技术检测**：分析HTTP头、HTML内容和JavaScript脚本
- **机器学习预测**：使用随机森林模型预测网站使用的技术
- **规则自我进化**：基于实际检测结果自动更新和优化规则
- **CMS指纹学习**：专门针对CMS网站进行指纹提取和学习
- **连续学习模式**：持续运行，不断提升检测准确率

### 1.2 技术栈

- **Python 3.6+**：核心开发语言
- **Requests**：HTTP请求处理
- **Scikit-learn**：机器学习模型
- **JSON**：规则存储格式
- **Bash**：部署和运行脚本

## 2. 系统架构

### 2.1 模块结构

```
tranwebfinger/
├── main.py                    # 核心Wappalyzer检测引擎
├── technologies.json          # 技术检测规则库
├── smart_targets.py           # 智能目标生成模块
├── ml_predictor.py            # 机器学习预测器
├── integrated_system.py       # 系统集成控制器
├── merge_rules.py             # 规则合并工具
├── update_rules.py            # 规则自动更新工具
├── config.json                # 系统配置文件
├── run.sh                     # 交互式运行脚本
└── package.sh                 # CentOS部署打包脚本
```

### 2.2 数据流图

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│ 智能目标生成器   │────▶│  Wappalyzer检测  │────▶│ 机器学习预测器  │
└─────────────────┘     └─────────────────┘     └─────────────────┘
          ▲                         │                         │
          │                         ▼                         ▼
          │                    ┌─────────────────┐     ┌─────────────────┐
          └────────────────────│ 规则进化引擎    │◀────│ 训练数据收集   │
                               └─────────────────┘     └─────────────────┘
```

## 3. 核心功能模块

### 3.1 智能目标生成器 (`smart_targets.py`)

负责从多种来源获取真实、可访问的网站目标，支持行业筛选和技术类别筛选。

#### 3.1.1 主要功能

- **多源目标获取**：支持Alexa、Tranco等顶级网站列表
- **网站验证**：验证域名有效性和可访问性
- **行业筛选**：支持电子商务、教育、金融、医疗健康、科技等行业
- **技术类别筛选**：支持CMS等技术类别
- **子域名枚举**：获取指定域名的子域名

#### 3.1.2 行业支持列表

| 行业 | 说明 | 示例网站 |
|------|------|----------|
| 电子商务 | 在线购物和电商平台 | amazon.com, taobao.com |
| 教育 | 教育机构和在线学习平台 | harvard.edu, coursera.org |
| 金融 | 金融服务和银行网站 | jpmorgan.com, chase.com |
| 医疗健康 | 医疗和健康相关网站 | mayoclinic.org, webmd.com |
| 科技 | 科技公司和技术媒体 | google.com, microsoft.com |

### 3.2 Wappalyzer检测引擎 (`main.py`)

核心检测模块，基于规则和机器学习进行网站技术检测。

#### 3.2.1 检测维度

- **HTTP响应头**：分析Server、X-Powered-By等头信息
- **HTML内容**：检测特定标签、属性和文本内容
- **JavaScript脚本**：分析脚本URL和内容中的技术线索

#### 3.2.2 规则格式

采用Wappalyzer兼容的JSON格式，示例：

```json
{
  "WordPress": {
    "name": "WordPress",
    "description": "开源内容管理系统",
    "category": "CMS",
    "headers": {},
    "html": ["wordpress"],
    "scripts": ["wordpress"]
  }
}
```

### 3.3 机器学习预测器 (`ml_predictor.py`)

使用随机森林分类器预测网站使用的技术，基于TF-IDF特征提取。

#### 3.3.1 核心算法

- **TF-IDF向量器**：将网站内容转换为数值特征
- **随机森林分类器**：多决策树集成学习，提高预测准确率
- **模型更新机制**：支持在线学习，不断优化模型

#### 3.3.2 模型文件

- `tech_predictor_model.pkl`：训练好的随机森林模型
- `vectorizer.pkl`：TF-IDF向量器

### 3.4 集成系统控制器 (`integrated_system.py`)

系统的中央控制器，协调各个模块的工作流程。

#### 3.4.1 主要工作流程

1. **智能获取网站目标**：根据配置获取真实网站
2. **扫描和数据收集**：检测网站技术，收集训练数据
3. **模型训练和更新**：使用新数据优化机器学习模型
4. **规则进化**：基于检测结果更新技术规则
5. **结果统计和保存**：保存更新后的规则和模型

#### 3.4.2 关键方法

- `smart_collect_and_learn()`：单次学习流程
- `run_continuous_learning()`：连续学习模式
- `cms_fingerprint_learning()`：CMS指纹专门学习

## 4. 使用方法

### 4.1 交互式运行

使用`run.sh`脚本启动交互式菜单：

```bash
chmod +x run.sh
./run.sh
```

#### 4.1.1 菜单选项

1. **常规运行（单次学习）**：执行一次完整的学习流程
2. **连续学习模式**：持续运行学习流程（默认3轮，每轮5个网站）
3. **CMS指纹学习**：专门针对CMS网站进行指纹学习
4. **特定行业网站学习**：选择特定行业进行网站学习
5. **特定行业CMS指纹学习**：针对特定行业的CMS网站进行学习
6. **退出**：退出系统

### 4.2 命令行直接运行

#### 4.2.1 单次学习

```bash
python3 -c "from integrated_system import IntegratedWappalyzerSystem; integrated_system = IntegratedWappalyzerSystem(); integrated_system.smart_collect_and_learn(10)"
```

#### 4.2.2 连续学习

```bash
python3 integrated_system.py
```

#### 4.2.3 特定行业学习

```bash
python3 -c "from integrated_system import IntegratedWappalyzerSystem; integrated_system = IntegratedWappalyzerSystem(); integrated_system.smart_collect_and_learn(10, industry='technology')"
```

#### 4.2.4 CMS指纹学习

```bash
python3 -c "from integrated_system import IntegratedWappalyzerSystem; integrated_system = IntegratedWappalyzerSystem(); integrated_system.cms_fingerprint_learning(10, 2, industry='ecommerce')"
```

## 5. 配置说明

### 5.1 主配置文件 (`config.json`)

```json
{
  "self_evolving_wappalyzer": {
    "rules_file": "technologies.json",
    "timeout": 10,
    "scan_headers": true,
    "scan_html": true,
    "scan_scripts": true,
    "evolution_enabled": true,
    "confidence_threshold": 0.7,
    "log_evolution": true,
    "max_evolution_events": 100
  }
}
```

### 5.2 智能目标生成器配置

在`smart_targets.py`的`__init__`方法中配置：

```python
self.config = {
    'max_targets': 100,
    'validation_timeout': 5,
    'sources': {
        'alexa': True,
        'ct_logs': False,
        'search_engines': False,
        'dns_enum': False,
        'subdomains': False
    },
    'filters': {
        'tld': [],
        'country': [],
        'min_estimated_visits': 0,
        'tech_category': [],
        'industry': []
    }
}
```

## 6. 部署指南

### 6.1 CentOS部署

#### 6.1.1 系统要求

- CentOS 7+ 或 Rocky Linux 8+
- Python 3.6+
- 至少1GB内存
- 网络连接（用于获取网站数据）

#### 6.1.2 自动化部署

使用提供的打包脚本生成部署包：

```bash
chmod +x package.sh
./package.sh
```

这将生成一个`self_evolving_wappalyzer-YYYYMMDD.tar.gz`文件，包含所有必要的文件和脚本。

#### 6.1.3 手动部署

1. **安装依赖**：
   ```bash
   yum install -y python3 python3-pip
   pip3 install requests scikit-learn numpy
   ```

2. **复制文件**：将所有Python文件和配置文件复制到服务器

3. **运行系统**：
   ```bash
   python3 integrated_system.py
   ```

## 7. 扩展开发

### 7.1 添加新的技术检测规则

编辑`technologies.json`文件，添加新的技术规则：

```json
{
  "YourTechnology": {
    "name": "YourTechnology",
    "description": "技术描述",
    "category": "技术类别",
    "headers": {
      "X-Your-Header": ["pattern1", "pattern2"]
    },
    "html": ["regex_pattern1", "regex_pattern2"],
    "scripts": ["script_pattern1", "script_pattern2"]
  }
}
```

### 7.2 添加新的行业网站

在`smart_targets.py`的`get_industry_websites`方法中添加新的行业网站列表：

```python
industry_websites = {
    'new_industry': [
        "https://example1.com",
        "https://example2.com"
    ]
}
```

### 7.3 自定义机器学习模型

修改`ml_predictor.py`中的模型参数：

```python
self.model = RandomForestClassifier(
    n_estimators=100,  # 决策树数量
    max_depth=10,       # 树的最大深度
    random_state=42     # 随机种子
)
```

## 8. 故障排除

### 8.1 常见问题

#### 8.1.1 无法获取网站

**问题**：系统无法获取到有效网站

**解决方案**：
- 检查网络连接是否正常
- 调整`smart_targets.py`中的超时设置
- 确保DNS配置正确
- 尝试使用不同的网站来源

#### 8.1.2 检测结果不准确

**问题**：检测到的技术与实际不符

**解决方案**：
- 运行多次学习流程，让模型更好地学习
- 手动调整`technologies.json`中的规则
- 添加更多的训练数据
- 检查机器学习模型的置信度阈值

#### 8.1.3 内存不足

**问题**：系统运行时出现内存不足错误

**解决方案**：
- 减少每轮扫描的网站数量
- 降低机器学习模型的复杂度
- 增加系统内存
- 关闭不必要的进程

#### 8.1.4 规则更新失败

**问题**：规则无法自动更新

**解决方案**：
- 确保`evolution_enabled`配置为`true`
- 检查日志文件，查看具体错误信息
- 确保对`technologies.json`文件有写入权限

## 9. 日志文件

系统生成以下日志文件，用于调试和监控：

- `integrated_system.log`：集成系统运行日志
- `smart_targets.log`：智能目标生成日志
- `ml_predictor.log`：机器学习模型日志

## 10. 性能优化

### 10.1 扫描性能

- 减少每轮扫描的网站数量
- 调整超时设置，避免长时间等待
- 并行扫描多个网站（可扩展功能）

### 10.2 模型性能

- 调整随机森林的参数
- 使用更高效的特征提取方法
- 定期重新训练模型
- 增加训练数据量

### 10.3 规则管理

- 定期清理过时的规则
- 合并相似的规则
- 优化正则表达式模式

## 11. 安全考虑

### 11.1 网络安全

- 所有HTTP请求使用超时设置，防止被恶意网站挂起
- 限制并发请求数量，避免DDoS嫌疑
- 尊重网站的robots.txt规则（可扩展功能）

### 11.2 数据安全

- 不存储任何敏感信息
- 训练数据仅用于模型优化，不对外泄露
- 规则文件使用只读权限（运行时可写）

## 12. 未来扩展

- [ ] 支持更多的网站来源（如CT Logs、搜索引擎API）
- [ ] 实现并行扫描，提高效率
- [ ] 添加GUI界面，方便用户操作
- [ ] 支持更多的机器学习算法
- [ ] 实现规则版本控制
- [ ] 添加API接口，支持外部系统调用

## 13. 版本历史

| 版本 | 日期 | 主要变更 |
|------|------|----------|
| 1.0 | 2026-01-11 | 初始版本，包含核心功能 |
| 1.1 | 2026-01-XX | 添加行业筛选功能 |
| 1.2 | 2026-01-XX | 优化机器学习模型 |
| 1.3 | 2026-02-XX | 添加并行扫描功能 |

## 14. 联系方式

如有问题或建议，请联系开发团队。

---

**文档版本**：1.0
**最后更新**：2026-01-11
**作者**：Self-Evolving Wappalyzer Team