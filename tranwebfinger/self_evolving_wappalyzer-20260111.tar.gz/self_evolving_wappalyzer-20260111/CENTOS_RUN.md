# 在CentOS上运行自进化Wappalyzer系统

## 系统要求
- CentOS 7+ 或 Rocky Linux 8+
- Python 3.6+
- 至少1GB内存

## 安装步骤

1. **安装Python**
   ```bash
   yum install -y python3 python3-pip
   ```

2. **安装依赖**
   ```bash
   chmod +x install_deps.sh
   ./install_deps.sh
   ```

3. **运行系统**
   ```bash
   chmod +x run.sh
   ./run.sh
   ```

## 运行选项

### 选项1：单次运行集成系统
执行一次完整的学习流程：
- 智能获取网站
- 扫描识别技术
- 训练机器学习模型
- 更新规则

### 选项2：连续学习模式
持续运行学习流程（默认3轮，每轮5个网站）

### 选项3：CMS指纹学习
专门针对CMS技术进行指纹学习和更新

### 选项4：启动Web仪表盘
启动Web仪表盘，用于展示新获得的指纹信息：
- 访问地址：http://localhost:5001
- 展示统计信息卡片
- 以表格形式展示指纹信息
- 支持数据刷新

## 项目文件说明

| 文件 | 功能 |
|------|------|
| main.py | 主Wappalyzer系统 |
| integrated_system.py | 集成系统控制器 |
| smart_targets.py | 智能目标生成器 |
| ml_predictor.py | 机器学习预测器 |
| web_dashboard.py | Web仪表盘应用 |
| templates/index.html | Web仪表盘HTML模板 |
| technologies.json | 技术检测规则 |
| config.json | 系统配置 |
| education_sites.json | 教育网站列表 |
| scan_results.json | 扫描结果 |
| merge_rules.py | 规则合并工具 |
| update_rules.py | 规则更新工具 |
| inspect_baidu.py | 百度网站检查工具 |
| generate_education_sites.py | 教育网站生成器 |
| demo_url_recognition.py | URL识别演示 |

## 自定义配置

### 修改连续学习参数
编辑 `integrated_system.py` 文件，修改以下行：
```python
# 运行连续学习模式
# 参数1：学习轮数
# 参数2：每轮获取的网站数量
integrated_system.run_continuous_learning(3, 5)
```

### 修改智能目标生成器配置
编辑 `smart_targets.py` 文件，修改 `__init__` 方法中的配置

### 修改检测规则
编辑 `technologies.json` 文件，添加或修改检测规则

## 日志文件

系统生成以下日志文件：
- `integrated_system.log`：集成系统日志
- `smart_targets.log`：智能目标生成器日志
- `ml_predictor.log`：机器学习预测器日志

## 故障排除

### 问题：无法获取网站
解决方案：
- 检查网络连接
- 检查DNS配置
- 调整 `smart_targets.py` 中的超时设置

### 问题：检测结果不准确
解决方案：
- 运行多次学习流程，让模型更好地学习
- 添加更多训练数据
- 手动调整 `technologies.json` 中的规则

### 问题：内存不足
解决方案：
- 减少每轮扫描的网站数量
- 减少机器学习模型的复杂度
- 增加系统内存
