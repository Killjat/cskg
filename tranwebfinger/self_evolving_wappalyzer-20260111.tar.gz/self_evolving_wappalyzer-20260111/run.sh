#!/bin/bash

# 运行脚本

echo "=== 自进化Wappalyzer系统 ==="
echo "1. 运行集成系统（单次）"
echo "2. 运行集成系统（连续学习模式）"
echo "3. CMS指纹学习（更新CMS指纹）"
echo "4. 启动Web仪表盘"
echo "5. 运行自动化执行（推荐）"
echo "6. 退出"

echo -n "请选择操作："
read choice

case $choice in
    1)
        echo "运行集成系统（单次）..."
        python3 -c "from integrated_system import IntegratedWappalyzerSystem; integrated_system = IntegratedWappalyzerSystem(); integrated_system.smart_collect_and_learn(10)"
        ;;
    2)
        echo "运行集成系统（连续学习模式）..."
        python3 integrated_system.py
        ;;
    3)
        echo "运行CMS指纹学习（更新CMS指纹）..."
        python3 -c "from integrated_system import IntegratedWappalyzerSystem; integrated_system = IntegratedWappalyzerSystem(); integrated_system.cms_fingerprint_learning(10, 2)"
        ;;
    4)
        echo "启动Web仪表盘..."
        echo "Web仪表盘将在 http://localhost:5001 上运行"
        echo "按 Ctrl+C 停止服务器"
        python3 web_dashboard.py
        ;;
    5)
        echo "启动自动化执行..."
        echo "自动化执行将持续运行，无需用户输入"
        echo "Web仪表盘将自动启动，访问地址：http://localhost:5001"
        echo "按 Ctrl+C 停止服务器"
        python3 auto_run.py
        ;;
    6)
        echo "退出"
        exit 0
        ;;
    *)
        echo "无效选择"
        exit 1
        ;;
esac
